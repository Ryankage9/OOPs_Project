package com.OOPSg22.major.repository;

import com.OOPSg22.major.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role,Integer> {
}
